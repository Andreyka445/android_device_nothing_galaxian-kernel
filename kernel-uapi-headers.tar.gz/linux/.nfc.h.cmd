cmd_usr/include/linux/nfc.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/nfc.h usr/include/linux/nfc.h

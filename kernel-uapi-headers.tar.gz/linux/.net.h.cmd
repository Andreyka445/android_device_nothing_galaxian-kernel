cmd_usr/include/linux/net.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/net.h usr/include/linux/net.h

cmd_usr/include/linux/ccs.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/ccs.h usr/include/linux/ccs.h

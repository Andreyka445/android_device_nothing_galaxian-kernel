cmd_usr/include/linux/rds.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/rds.h usr/include/linux/rds.h

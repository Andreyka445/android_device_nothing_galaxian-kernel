cmd_usr/include/linux/wmi.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/wmi.h usr/include/linux/wmi.h

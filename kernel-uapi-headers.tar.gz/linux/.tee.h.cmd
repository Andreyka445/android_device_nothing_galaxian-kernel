cmd_usr/include/linux/tee.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/tee.h usr/include/linux/tee.h

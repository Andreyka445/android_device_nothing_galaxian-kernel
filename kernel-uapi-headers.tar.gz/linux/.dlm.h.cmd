cmd_usr/include/linux/dlm.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/dlm.h usr/include/linux/dlm.h

cmd_usr/include/linux/tcp.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/tcp.h usr/include/linux/tcp.h

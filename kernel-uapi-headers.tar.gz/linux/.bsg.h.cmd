cmd_usr/include/linux/bsg.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/bsg.h usr/include/linux/bsg.h

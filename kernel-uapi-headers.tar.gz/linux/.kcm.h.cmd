cmd_usr/include/linux/kcm.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/kcm.h usr/include/linux/kcm.h

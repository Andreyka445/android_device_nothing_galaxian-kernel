cmd_usr/include/linux/nbd.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/nbd.h usr/include/linux/nbd.h

cmd_usr/include/linux/i8k.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/i8k.h usr/include/linux/i8k.h

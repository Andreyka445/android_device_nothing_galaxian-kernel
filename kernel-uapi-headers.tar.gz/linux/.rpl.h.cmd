cmd_usr/include/linux/rpl.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/rpl.h usr/include/linux/rpl.h

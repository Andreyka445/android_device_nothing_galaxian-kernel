cmd_usr/include/linux/gtp.h := sh /home/KSN/infinityx/kernel/nothing/galaxian/scripts/headers_install.sh /home/KSN/infinityx/kernel/nothing/galaxian/include/uapi/linux/gtp.h usr/include/linux/gtp.h
